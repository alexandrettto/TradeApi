# TradeApi
Python обертка для FinamTradeApi
